<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="spring"   uri="http://www.springframework.org/tags" %>   
    
<!DOCTYPE html>
<html>
<head>
            <link href="webjars/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet">

<meta charset="ISO-8859-1">
<title>Delivery update Form</title>
</head>

<spring:url value="/saveDeliveryStatus" var="saveURL" />
 
<section class="container">

 <div class="row">
        <div class="thumbnail">
           <div class="caption">
    <form:form modelAttribute="deliveryStatusForm" method="post" action="${saveURL }" >
   <form:hidden path="orderId"/> 
  <table class="table table-hover">
  
     <tr>
          <th class="text-center">DELIVERY STATUS</th>
     </tr>
     <tr>
          <td class="text-center">
              <form:input path="delivery_status"/>
          </td>
          
          <td class="text-center">
              <button type="submit">Save</button>
          </td>
      </tr>    
     
  </table>
  
 </form:form>
 </div>
 </div>
 </div>
 </section>  


</body>
</html>