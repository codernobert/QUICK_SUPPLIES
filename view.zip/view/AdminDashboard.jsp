<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<%@taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/sql" prefix="sql"%>
<%@ page import="javax.servlet.http.*,javax.servlet.*" %>
<%@ page import="java.util.*,java.sql.*" %>
<%@ page import="com.google.gson.Gson"%>
<%@ page import="com.google.gson.JsonObject"%>
 

 
<!DOCTYPE HTML>
<html>
<head>
 <style>
               /* Google Fonts Import Link */
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap');
*{
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: 'Poppins', sans-serif;
}
.sidebar{
  position: fixed;
  top: 0;
  left: 0;
  height: 100%;
  width: 260px;
  background: #11101d;
  z-index: 100;
  transition: all 0.5s ease;
}
.sidebar.close{
  width: 78px;
}
.sidebar .logo-details{
  height: 60px;
  width: 100%;
  display: flex;
  align-items: center;
}
.sidebar .logo-details i{
  font-size: 30px;
  color: #fff;
  height: 50px;
  min-width: 78px;
  text-align: center;
  line-height: 50px;
}
.sidebar .logo-details .logo_name{
  font-size: 22px;
  color: #fff;
  font-weight: 600;
  transition: 0.3s ease;
  transition-delay: 0.1s;
}
.sidebar.close .logo-details .logo_name{
  transition-delay: 0s;
  opacity: 0;
  pointer-events: none;
}
.sidebar .nav-links{
  height: 100%;
  padding: 30px 0 150px 0;
  overflow: auto;
}
.sidebar.close .nav-links{
  overflow: visible;
}
.sidebar .nav-links::-webkit-scrollbar{
  display: none;
}
.sidebar .nav-links li{
  position: relative;
  list-style: none;
  transition: all 0.4s ease;
}
.sidebar .nav-links li:hover{
  background: #1d1b31;
}
.sidebar .nav-links li .iocn-link{
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.sidebar.close .nav-links li .iocn-link{
  display: block
}
.sidebar .nav-links li i{
  height: 50px;
  min-width: 78px;
  text-align: center;
  line-height: 50px;
  color: #fff;
  font-size: 20px;
  cursor: pointer;
  transition: all 0.3s ease;
}
.sidebar .nav-links li.showMenu i.arrow{
  transform: rotate(-180deg);
}
.sidebar.close .nav-links i.arrow{
  display: none;
}
.sidebar .nav-links li a{
  display: flex;
  align-items: center;
  text-decoration: none;
}
.sidebar .nav-links li a .link_name{
  font-size: 18px;
  font-weight: 400;
  color: #fff;
  transition: all 0.4s ease;
}
.sidebar.close .nav-links li a .link_name{
  opacity: 0;
  pointer-events: none;
}
.sidebar .nav-links li .sub-menu{
  padding: 6px 6px 14px 80px;
  margin-top: -10px;
  background: #1d1b31;
  display: none;
}
.sidebar .nav-links li.showMenu .sub-menu{
  display: block;
}
.sidebar .nav-links li .sub-menu a{
  color: #fff;
  font-size: 15px;
  padding: 5px 0;
  white-space: nowrap;
  opacity: 0.6;
  transition: all 0.3s ease;
}
.sidebar .nav-links li .sub-menu a:hover{
  opacity: 1;
}
.sidebar.close .nav-links li .sub-menu{
  position: absolute;
  left: 100%;
  top: -10px;
  margin-top: 0;
  padding: 10px 20px;
  border-radius: 0 6px 6px 0;
  opacity: 0;
  display: block;
  pointer-events: none;
  transition: 0s;
}
.sidebar.close .nav-links li:hover .sub-menu{
  top: 0;
  opacity: 1;
  pointer-events: auto;
  transition: all 0.4s ease;
}
.sidebar .nav-links li .sub-menu .link_name{
  display: none;
}
.sidebar.close .nav-links li .sub-menu .link_name{
  font-size: 18px;
  opacity: 1;
  display: block;
}
.sidebar .nav-links li .sub-menu.blank{
  opacity: 1;
  pointer-events: auto;
  padding: 3px 20px 6px 16px;
  opacity: 0;
  pointer-events: none;
}
.sidebar .nav-links li:hover .sub-menu.blank{
  top: 50%;
  transform: translateY(-50%);
}
.sidebar .profile-details{
  position: fixed;
  bottom: 0;
  width: 260px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  background: #1d1b31;
  padding: 12px 0;
  transition: all 0.5s ease;
}
.sidebar.close .profile-details{
  background: none;
}
.sidebar.close .profile-details{
  width: 78px;
}
.sidebar .profile-details .profile-content{
  display: flex;
  align-items: center;
}
.sidebar .profile-details img{
  height: 52px;
  width: 52px;
  object-fit: cover;
  border-radius: 16px;
  margin: 0 14px 0 12px;
  background: #1d1b31;
  transition: all 0.5s ease;
}
.sidebar.close .profile-details img{
  padding: 10px;
}
.sidebar .profile-details .profile_name,
.sidebar .profile-details .job{
  color: #fff;
  font-size: 18px;
  font-weight: 500;
  white-space: nowrap;
}
.sidebar.close .profile-details i,
.sidebar.close .profile-details .profile_name,
.sidebar.close .profile-details .job{
  display: none;
}
.sidebar .profile-details .job{
  font-size: 12px;
}
.home-section{
  position: relative;
  background: #E4E9F7;
  height: 100vh;
  left: 260px;
  width: calc(100% - 260px);
  transition: all 0.5s ease;
}
.sidebar.close ~ .home-section{
  left: 78px;
  width: calc(100% - 78px);
}
.home-section .home-content{
  height: 60px;
  display: flex;
  align-items: center;
}
.home-section .home-content .bx-menu,
.home-section .home-content .text{
  color: #11101d;
  font-size: 35px;
}
.home-section .home-content .bx-menu{
  margin: 0 15px;
  cursor: pointer;
}
.home-section .home-content .text{
  font-size: 26px;
  font-weight: 600;
}
@media (max-width: 420px) {
  .sidebar.close .nav-links li .sub-menu{
    display: none;
  }
}
       
   </style>
      <link href="webjars/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet">
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

</head>
<body style="background-color: PaleTurquoise;">

<div class="sidebar">
    <div class="logo-details">
      <i class='bx bxl-c-plus-plus'></i>
      <span class="logo_name">Admin</span>
    </div>
      <ul class="nav-links">
        <li>
          <a href="<c:url value="/AdminDashboard" />" class="active">
            <i class='bx bx-grid-alt' ></i>
            <span class="links_name">Dashboard</span>
          </a>
        </li>
        <li>
          <a href="<c:url value="/suppliers" />">
            <i class='bx bx-box' ></i>
            <span class="links_name">Suppliers</span>
          </a>
        </li>
        <li>
          <a href="<c:url value="/editProducts" />">
            <i class='bx bx-box' ></i>
            <span class="links_name">Products</span>
          </a>
        </li>
        <li>
        <li>
          <a href="<c:url value="/makeOrders" />">
            <i class='bx bx-coin-stack' ></i>
            <span class="links_name">Add Orders</span>
          </a>
        </li>
        <li>
          <a href="<c:url value="/Orders_Made" />">
            <i class='bx bx-book-alt' ></i>
            <span class="links_name">Orders</span>
          </a>
        </li>
        <li>
          <a href="<c:url value="/products_report" />">
            <i class='bx bx-heart' ></i>
            <span class="links_name">Product Reports</span>
          </a>
        </li>
        <li>
          <a href="<c:url value="/orders_report" />">
            <i class='bx bx-heart' ></i>
            <span class="links_name">Orders Reports</span>
          </a>
        </li>
        <li>
          <a href="<c:url value="/supplier_report" />">
            <i class='bx bx-heart' ></i>
            <span class="links_name">Supplier Reports</span>
          </a>
        </li>
        <li class="log_out">
          <a href="<c:url value="/logout" />">
            <i class='bx bx-log-out'></i>
            <span class="links_name">Log out</span>
          </a>
        </li>
      </ul>
  </div>

<br>
<section class="container" style="margin-left:25%;margin-right:6%;height:220px;padding:1px 16px;">
<button style=" display:inline-block; padding: 35px 45px;
        font-size: 38px;              cursor: pointer;
        text-align: center;           text-decoration: none;
	    outline: none;                color: #fff;
	    background-color: #4CAF50;    border: none;
        border-radius: 15px;          box-shadow: 0 9px #999; ">
<%
Statement statement= null;

try{
	Class.forName("com.mysql.cj.jdbc.Driver"); 
	Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/palm_technologies", "root", "0701839432");
	statement = connection.createStatement();
	
	ResultSet rs = statement.executeQuery("SELECT COUNT(*) AS NumberOfOrders FROM orders_made");
	
	while(rs.next()){
		int NumberOfOrders  = rs.getInt("NumberOfOrders");
		  out.println("" + rs.getInt("NumberOfOrders") + " order(s)");
	}
	statement.close();
}
catch(SQLException e){
	out.println("<div  style='width: 50%; margin-left: auto; margin-right: auto; margin-top: 200px;.button:hover {background-color: #3e8e41}'>Could not connect to the database. Please check if you have mySQL Connector installed on the machine - if not, try installing the same.</div>");
			
}
%>
</button>

<button style=" display:inline-block; padding: 35px 45px;
        font-size: 38px;              cursor: pointer;
        text-align: center;           text-decoration: none;
	    outline: none;                color: #fff;
	    background-color: #008CBA;    border: none;
        border-radius: 15px;          box-shadow: 0 9px #999; ">
<%
Statement stat= null;

try{
	Class.forName("com.mysql.cj.jdbc.Driver"); 
	Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/palm_technologies", "root", "0701839432");
	stat = connection.createStatement();
	
	ResultSet rs = stat.executeQuery("SELECT COUNT(*) AS NumberOfSuppliers FROM suppliers");
	
	while(rs.next()){
		int NumberOfSuppliers  = rs.getInt("NumberOfSuppliers");
		  out.println("" + rs.getInt("NumberOfSuppliers") + " Supplier(s)");
	}
	stat.close();
}
catch(SQLException e){
	out.println("<div  style='width: 50%; margin-left: auto; margin-right: auto; margin-top: 200px;.button:hover {background-color: #3e8e41}'>Could not connect to the database. Please check if you have mySQL Connector installed on the machine - if not, try installing the same.</div>");
			
}
%>
</button>

<button style=" display:inline-block; padding: 35px 45px;
        font-size: 38px;              cursor: pointer;
        text-align: center;           text-decoration: none;
	    outline: none;                color: #fff;
	    background-color: Sienna;    border: none;
        border-radius: 15px;          box-shadow: 0 9px #999; ">
<%
Statement statm= null;

try{
	Class.forName("com.mysql.cj.jdbc.Driver"); 
	Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/palm_technologies", "root", "0701839432");
	statm = connection.createStatement();
	
	ResultSet rs = statm.executeQuery("SELECT COUNT(*) AS NumberOfProducts FROM products");
	
	while(rs.next()){
		int NumberOfProducts  = rs.getInt("NumberOfProducts");
		  out.println("" + rs.getInt("NumberOfProducts") + " Product(s)");
	}
	statm.close();
}
catch(SQLException e){
	out.println("<div  style='width: 50%; margin-left: auto; margin-right: auto; margin-top: 200px;.button:hover {background-color: #3e8e41}'>Could not connect to the database. Please check if you have mySQL Connector installed on the machine - if not, try installing the same.</div>");
			
}
%>
</button>

</section>


<section class="container" style="margin-left:25%;margin-right:6%;height:220px;padding:1px 16px;">
      <div class="row">
        <div class="thumbnail">
           <div class="caption">
          
           
           
                   <table class="table table-hover">
                            <tr>
                                <th colspan="10" class="text-center">
                                    Services
                                </th>  
                            </tr> 
                            <tr>
                                <th class="text-center">1</th>
                                <th class="text-center">2</th>
                                <th class="text-center">3</th>
                                <th class="text-center">4</th>
                                
                            </tr>
                         
                            <tr>
                                <td class="text-center"><strong>Add and Update Products</strong></td>
                                <td class="text-center"><strong>Add and Update Suppliers</strong></td>
                                <td class="text-center"><strong>Make Orders and Generate Receipts</strong></td>
                                <td class="text-center"><strong>Generate Reports</strong></td>
                     
                            </tr>
                       
                        </table>
                        
              </div>
           </div>
         </div>
  </section>
  <br><br><br><br>
<button type="button" class="btn btn-primary active">Active Primary</button>
  
</body>
</html>  