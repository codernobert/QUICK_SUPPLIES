<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<html>
<head>
<title>Update</title>
</head>
<body>
	
<form action="../updateDev" method="post">
<pre>
<c:forEach var="delivery" items="${listDeliveries}">
		
	   Order Id:   <input type="text" name="orderId" value="${delivery.orderId}" disabled="disabled"/>
		           <input type="hidden" name="orderId" value="${delivery.orderId}"/>
		           
Delivery Status:   <input type="text" name="delivery_status" value="${delivery.delivery_status}" />

        <input type="submit" value="Update" />	
</c:forEach>	
</pre>
</form>
${msg}
</body>
</html>