<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="spring"   uri="http://www.springframework.org/tags" %>   
    
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>supplier update form</title>
</head>
<body>
<spring:url value="/saveSupplier" var="saveURL" />
 
<section class="container">

 <div class="row">
        <div class="thumbnail">
           <div class="caption">
    <form:form modelAttribute="supplierForm" method="post" action="${saveURL }" >
   <form:hidden path="supplier_Id"/> 
  <table class="table table-hover">
     <tr>
          <th class="text-center">SUPPLIER NAME</th>
          <th class="text-center">CONTACT</th>
          <th class="text-center">ADDRESS</th>
     </tr>
     <tr>
          <td class="text-center">
              <form:input path="name"/>
          </td>
          <td class="text-center">
              <form:input path="contact"/>
          </td>
          <td class="text-center">
              <form:input path="address"/>
          </td>
          <td class="text-center">
              <button type="submit">Save</button>
          </td>
      </tr>
  </table>
  
 </form:form>
 </div>
 </div>
 </div>
 </section>
</body>
</html>