<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="spring" uri="http://www.springframework.org/tags" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt"%>

<!DOCTYPE html>
<html>
<head>
     <link href="webjars/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet">
<meta charset="ISO-8859-1">
<title>Payment Receipt</title>

</head>
<body style="background-color: PaleTurquoise;">

<br><br>
                  <div class="container" style="margin-left:60%;"> 
                        <spring:url value="/receiptDownload/?type=pdf" var="pdfURL" />
                        <a href="${pdfURL }">
                           <button type="button" class="btn btn-primary">
                             <span class="glyphicon glyphicon-download-alt"></span> Download Receipt
                           </button>  
                        </a>
                   </div> <br>                      
       <div class="container">
                    
            <div class="row">
                <form:form modelAttribute="order" class="form-horizontal">
                    <input type="hidden" name="_flowExecutionKey" value="${flowExecutionKey}" />
                       <div class="well col-xs-10 col-sm-10 col-md-6 col-xs-offset-1 col-sm-offset-1 col-md-offset-3">
                           <div class="text-center">
                                <h1>Receipt</h1>
                           </div>
 
                              <div class="row">
                              
                              <div class="col-xs-4 col-sm-4 col-md-4 pull-right">
                                 <strong><em>Date:</em></strong>
                                 <p id="demo"></p> 
                              </div>
  
                              </div>
                                     <div class="row">
                                         <div class="col-xs-6 col-sm-6 col-md-6">
                                              <address>
                                                   <strong>Billing Address</strong>
                                                        <br> <abbr >Name:</abbr>
                                                        ${receipt.owner}
                                                        <br> <abbr >Phone Number:</abbr>
                                                        ${receipt.contact}
                                               </address>
                                          </div>
                                      </div>
                                      
                                      <div class="row">
                                            <table class="table table-hover">
                                                  <thead>
                                                       <tr>
                                                           <th class="text-center">Product</th>
                                                           <th class="text-center">Product Id</th>
                                                           <th class="text-center">Quantity</th>
                                                           <th class="text-center">Price</th>
                                                           <th class="text-center">Total</th>
                                                       </tr>
                                                   </thead>
                                                   <tbody>
                                                      
                                                         <tr>
                                                             <td>
                                                                <em>${receipt.product}</em>
                                                             </td>
                                                             <td class="text-center">
                                                                 ${receipt.productId}
                                                             </td>
                                                             <td class="text-center">
                                                                 ${receipt.quantity}
                                                             </td>
                                                             <td class="text-center">
                                                                  KSH ${receipt.unitPrice}
                                                             </td>
                                                             <td class="text-center">
                                                                 KSH ${receipt.unitPrice}
                                                             </td>
                                                          </tr>
                                                 
                                                      <tr>
                                                           <td> </td>
                                                           <td> </td>
                                                           <td class="text-right">
                                                               <h4>
                                                                    <strong>Grand Total:</strong>
                                                               </h4>
                                                           </td>
                                                           <td class="text-center text-danger">
                                                               <h4>
                                                                   <strong>KSH ${receipt.unitPrice}</strong>
                                                               </h4>
                                                           </td>
                                                        </tr>
                                                      </tbody>
                                            </table>
 
                                 
                                 </div>
                             </div>
             </form:form>
          </div>
      </div>
            <div class="container" style="margin-left:29%;">
               <div class="row">
               <p>
                   <a href="<spring:url value="/Orders_Made" />" class="btn btn-primary">
                      <span class="glyphicon-hand-left glyphicon"></span> Back
                   </a>
               </p>
              </div> 
            </div>    

<script>
document.getElementById("demo").innerHTML = Date();
</script>

</body>
</html>