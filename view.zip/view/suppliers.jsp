<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="spring"   uri="http://www.springframework.org/tags" %> 
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
  <style>
               /* Google Fonts Import Link */
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap');
*{
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: 'Poppins', sans-serif;
}
.sidebar{
  position: fixed;
  top: 0;
  left: 0;
  height: 100%;
  width: 260px;
  background: #11101d;
  z-index: 100;
  transition: all 0.5s ease;
}
.sidebar.close{
  width: 78px;
}
.sidebar .logo-details{
  height: 60px;
  width: 100%;
  display: flex;
  align-items: center;
}
.sidebar .logo-details i{
  font-size: 30px;
  color: #fff;
  height: 50px;
  min-width: 78px;
  text-align: center;
  line-height: 50px;
}
.sidebar .logo-details .logo_name{
  font-size: 22px;
  color: #fff;
  font-weight: 600;
  transition: 0.3s ease;
  transition-delay: 0.1s;
}
.sidebar.close .logo-details .logo_name{
  transition-delay: 0s;
  opacity: 0;
  pointer-events: none;
}
.sidebar .nav-links{
  height: 100%;
  padding: 30px 0 150px 0;
  overflow: auto;
}
.sidebar.close .nav-links{
  overflow: visible;
}
.sidebar .nav-links::-webkit-scrollbar{
  display: none;
}
.sidebar .nav-links li{
  position: relative;
  list-style: none;
  transition: all 0.4s ease;
}
.sidebar .nav-links li:hover{
  background: #1d1b31;
}
.sidebar .nav-links li .iocn-link{
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.sidebar.close .nav-links li .iocn-link{
  display: block
}
.sidebar .nav-links li i{
  height: 50px;
  min-width: 78px;
  text-align: center;
  line-height: 50px;
  color: #fff;
  font-size: 20px;
  cursor: pointer;
  transition: all 0.3s ease;
}
.sidebar .nav-links li.showMenu i.arrow{
  transform: rotate(-180deg);
}
.sidebar.close .nav-links i.arrow{
  display: none;
}
.sidebar .nav-links li a{
  display: flex;
  align-items: center;
  text-decoration: none;
}
.sidebar .nav-links li a .link_name{
  font-size: 18px;
  font-weight: 400;
  color: #fff;
  transition: all 0.4s ease;
}
.sidebar.close .nav-links li a .link_name{
  opacity: 0;
  pointer-events: none;
}
.sidebar .nav-links li .sub-menu{
  padding: 6px 6px 14px 80px;
  margin-top: -10px;
  background: #1d1b31;
  display: none;
}
.sidebar .nav-links li.showMenu .sub-menu{
  display: block;
}
.sidebar .nav-links li .sub-menu a{
  color: #fff;
  font-size: 15px;
  padding: 5px 0;
  white-space: nowrap;
  opacity: 0.6;
  transition: all 0.3s ease;
}
.sidebar .nav-links li .sub-menu a:hover{
  opacity: 1;
}
.sidebar.close .nav-links li .sub-menu{
  position: absolute;
  left: 100%;
  top: -10px;
  margin-top: 0;
  padding: 10px 20px;
  border-radius: 0 6px 6px 0;
  opacity: 0;
  display: block;
  pointer-events: none;
  transition: 0s;
}
.sidebar.close .nav-links li:hover .sub-menu{
  top: 0;
  opacity: 1;
  pointer-events: auto;
  transition: all 0.4s ease;
}
.sidebar .nav-links li .sub-menu .link_name{
  display: none;
}
.sidebar.close .nav-links li .sub-menu .link_name{
  font-size: 18px;
  opacity: 1;
  display: block;
}
.sidebar .nav-links li .sub-menu.blank{
  opacity: 1;
  pointer-events: auto;
  padding: 3px 20px 6px 16px;
  opacity: 0;
  pointer-events: none;
}
.sidebar .nav-links li:hover .sub-menu.blank{
  top: 50%;
  transform: translateY(-50%);
}
.sidebar .profile-details{
  position: fixed;
  bottom: 0;
  width: 260px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  background: #1d1b31;
  padding: 12px 0;
  transition: all 0.5s ease;
}
.sidebar.close .profile-details{
  background: none;
}
.sidebar.close .profile-details{
  width: 78px;
}
.sidebar .profile-details .profile-content{
  display: flex;
  align-items: center;
}
.sidebar .profile-details img{
  height: 52px;
  width: 52px;
  object-fit: cover;
  border-radius: 16px;
  margin: 0 14px 0 12px;
  background: #1d1b31;
  transition: all 0.5s ease;
}
.sidebar.close .profile-details img{
  padding: 10px;
}
.sidebar .profile-details .profile_name,
.sidebar .profile-details .job{
  color: #fff;
  font-size: 18px;
  font-weight: 500;
  white-space: nowrap;
}
.sidebar.close .profile-details i,
.sidebar.close .profile-details .profile_name,
.sidebar.close .profile-details .job{
  display: none;
}
.sidebar .profile-details .job{
  font-size: 12px;
}
.home-section{
  position: relative;
  background: #E4E9F7;
  height: 100vh;
  left: 260px;
  width: calc(100% - 260px);
  transition: all 0.5s ease;
}
.sidebar.close ~ .home-section{
  left: 78px;
  width: calc(100% - 78px);
}
.home-section .home-content{
  height: 60px;
  display: flex;
  align-items: center;
}
.home-section .home-content .bx-menu,
.home-section .home-content .text{
  color: #11101d;
  font-size: 35px;
}
.home-section .home-content .bx-menu{
  margin: 0 15px;
  cursor: pointer;
}
.home-section .home-content .text{
  font-size: 26px;
  font-weight: 600;
}
@media (max-width: 420px) {
  .sidebar.close .nav-links li .sub-menu{
    display: none;
  }
}
       
   </style>
      <link href="webjars/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet">
<meta charset="ISO-8859-1">
<title>Suppliers</title>
</head>
<body style="background-color: lightblue;">

<div class="sidebar">
    <div class="logo-details">
      <i class='bx bxl-c-plus-plus'></i>
      <span class="logo_name">Admin</span>
    </div>
      <ul class="nav-links">
        <li>
          <a href="<c:url value="/AdminDashboard" />" class="active">
            <i class='bx bx-grid-alt' ></i>
            <span class="links_name">Dashboard</span>
          </a>
        </li>
        <li>
          <a href="<c:url value="/suppliers" />">
            <i class='bx bx-box' ></i>
            <span class="links_name">Suppliers</span>
          </a>
        </li>
        <li>
          <a href="<c:url value="/editProducts" />">
            <i class='bx bx-box' ></i>
            <span class="links_name">Products</span>
          </a>
        </li>
        <li>
        <li>
          <a href="<c:url value="/makeOrders" />">
            <i class='bx bx-coin-stack' ></i>
            <span class="links_name">Add Orders</span>
          </a>
        </li>
        <li>
          <a href="<c:url value="/Orders_Made" />">
            <i class='bx bx-book-alt' ></i>
            <span class="links_name">Orders</span>
          </a>
        </li>
        <li>
          <a href="<c:url value="/products_report" />">
            <i class='bx bx-heart' ></i>
            <span class="links_name">Product Reports</span>
          </a>
        </li>
        <li>
          <a href="<c:url value="/orders_report" />">
            <i class='bx bx-heart' ></i>
            <span class="links_name">Orders Reports</span>
          </a>
        </li>
        <li>
          <a href="<c:url value="/supplier_report" />">
            <i class='bx bx-heart' ></i>
            <span class="links_name">Supplier Reports</span>
          </a>
        </li>
        <li class="log_out">
          <a href="<c:url value="/logout" />">
            <i class='bx bx-log-out'></i>
            <span class="links_name">Log out</span>
          </a>
        </li>
      </ul>
  </div>
<br><br>
<section class="container" style="margin-left:25%;margin-right:6%;height:220px;padding:1px 16px;">
      <div class="row">
        <div class="thumbnail">
           <div class="caption">
          
           
           
                         <table class="table table-hover">
                            <tr>
                                <th colspan="10" class="text-center">
                                    SUPPLIER DETAILS
                                </th>  
                            </tr> 
                            <tr>
                                
                                <th class="text-center">ID</th>
                                <th class="text-center">SUPPLIER NAME</th>
                                <th class="text-center">CONTACT</th>
                                <th class="text-center">ADDRESS</th>
                                <th class="text-center" colspan="2">ACTION</th>
                                
                            </tr>
                <c:forEach items="${suppliers}" var="supplier">          
                            <tr>
                                <td class="text-center">${supplier.supplier_Id}</td>
                                <td class="text-center">${supplier.name}</td>
                                <td class="text-center">${supplier.contact}</td>
                                <td class="text-center">${supplier.address}</td>                   
                                <td>
                                    <spring:url value="/updateSupplier/${supplier.supplier_Id}" var="updateURL" />
                                        <a href="${updateURL }"> 
                                            <button type="button" class="btn btn-success">
                                                <span class="glyphicon glyphicon-edit"></span> Update
                                            </button>
                                        </a>
                                </td>
                                
                                <td>
                                     <spring:url value="/deleteSupplier/${supplier.supplier_Id}" var="deleteURL" />
                                         <a href="${deleteURL }">
                                              <button type="button" class="btn btn-danger">
                                                 <span class="glyphicon glyphicon-remove"></span> Delete
                                              </button>  
                                         </a>
                                </td>
                            </tr>
                </c:forEach>             
                        </table>
                        
        </div>
                     <div> 
                        <a href="<c:url value="/add/supplier" />">
                           <button type="button" class="btn btn-primary">
                               <span class="glyphicon glyphicon-open"></span> Add Supplier
                           </button>  
                        </a>
                     </div> 
        </div>                 
    </div>                      
</section>
                    

</body>
</html>